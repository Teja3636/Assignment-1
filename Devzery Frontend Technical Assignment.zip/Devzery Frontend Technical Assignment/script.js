document.addEventListener('DOMContentLoaded', () => {
    const usersList = document.getElementById('users-list');
    const userDetailsContainer = document.getElementById('user-details-container');
    const userDetails = document.getElementById('user-details');
    const messageForm = document.getElementById('message-form');
    const messageContent = document.getElementById('message-content');
    const messageStatus = document.getElementById('message-status');
    const sentMessagesList = document.getElementById('sent-messages-list');
    let selectedUserId = null;

    // Function to fetch users from the local JSON file
    async function fetchUsers() {
        try {
            const response = await fetch('users.json'); // Fetch from local JSON file
            const users = await response.json();
            displayUsers(users);
        } catch (error) {
            usersList.innerHTML = '<li>Error fetching users</li>';
        }
    }

    // Display users
    function displayUsers(users) {
        usersList.innerHTML = '';
        users.forEach(user => {
            const li = document.createElement('li');
            li.textContent = user.name;
            li.addEventListener('click', () => {
                selectedUserId = user.id;
                displayUserDetails(user);
            });
            usersList.appendChild(li);
        });
    }

    // Display selected user details
    function displayUserDetails(user) {
        userDetailsContainer.style.display = 'block';
        userDetails.innerHTML = `
            <p><strong>Name:</strong> ${user.name}</p>
            <p><strong>Email:</strong> ${user.email}</p>
            <p><strong>Phone:</strong> ${user.phone}</p>
            <p><strong>Website:</strong> ${user.website}</p>
        `;
    }

    // Handle message submission (POST request)
    messageForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        if (!selectedUserId) {
            messageStatus.textContent = 'Please select a user first.';
            return;
        }

        const message = {
            userId: selectedUserId,
            content: messageContent.value
        };

        try {
            const response = await fetch('https://jsonplaceholder.typicode.com/posts', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(message)
            });

            if (response.ok) {
                // Add the sent message to the local list
                addMessageToSentList(message);
                messageStatus.textContent = 'Message sent successfully!';
                messageContent.value = '';
            } else {
                messageStatus.textContent = 'Failed to send message.';
            }
        } catch (error) {
            messageStatus.textContent = 'Failed to send message.';
        }
    });

    // Function to add the sent message to the list
    function addMessageToSentList(message) {
        const li = document.createElement('li');
        li.textContent = `To User ID ${message.userId}: ${message.content}`;
        sentMessagesList.appendChild(li);
    }

    // Initial fetch of users on page load
    fetchUsers();
});
